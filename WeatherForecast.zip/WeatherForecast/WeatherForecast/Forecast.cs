﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;          //for connecting to web
using System.Xml.Linq;     //for XML
using System.Xml;
using System.IO;

namespace Weather
{
    //a Forecast is responsible for the values of the current day and contains List of Singleforecasts(for 5 days each).
    //written by Elena Shuvaeva 11/04/2016
    public class Forecast
    {
        
        public List<SingleForecast> SingleForecasts { get; private set; }

        //getting Condition for the current day
       public string Condition
        {
            get
            {
                return SingleForecasts.FirstOrDefault().Condition;
            }
        }
        //getting Windspeed for the current day
        public string Windspeed
        {
            get
            {
                return SingleForecasts.FirstOrDefault().WindSpeed;
            }
        }


        public Town Town { get; set; }

        //getting Pressure for the current day
        public string Pressure
        {
            get
            {
                return SingleForecasts.FirstOrDefault().Pressure;
            }
        }

        //getting WindDirection for the current day

        public string WindDirection
        {
            get
            {
                return SingleForecasts.FirstOrDefault().WindDirection;
            }
        }

        //getting Temperature for the current day

        public string Temperature
        {
            get
            {
                return SingleForecasts.FirstOrDefault().Temperature;
            }
        }


        public Forecast(Town town, List<SingleForecast> singleForecasts)
        {
            Town = town;
            SingleForecasts = singleForecasts;
        }

    }
}
