﻿namespace Weather
{
    partial class WeatherControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTowns = new System.Windows.Forms.ComboBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.lblTemp = new System.Windows.Forms.Label();
            this.lblTown = new System.Windows.Forms.Label();
            this.lblCondName = new System.Windows.Forms.Label();
            this.lblPressureName = new System.Windows.Forms.Label();
            this.lblWindSpeed = new System.Windows.Forms.Label();
            this.lbl_condition = new System.Windows.Forms.Label();
            this.lbl_pressure = new System.Windows.Forms.Label();
            this.lblWind_Speed = new System.Windows.Forms.Label();
            this.lbl_windDirect = new System.Windows.Forms.Label();
            this.lblWindDirecName = new System.Windows.Forms.Label();
            this.lblTempName = new System.Windows.Forms.Label();
            this.lbl_date1 = new System.Windows.Forms.Label();
            this.lbl_condday1 = new System.Windows.Forms.Label();
            this.lbl_condday2 = new System.Windows.Forms.Label();
            this.lbl_date2 = new System.Windows.Forms.Label();
            this.lbl_condday3 = new System.Windows.Forms.Label();
            this.lbl_date3 = new System.Windows.Forms.Label();
            this.lbl_condDay4 = new System.Windows.Forms.Label();
            this.lbl_date4 = new System.Windows.Forms.Label();
            this.lbl_CountryName = new System.Windows.Forms.Label();
            this.lbl_tempday1 = new System.Windows.Forms.Label();
            this.lbl_windSpeedday1 = new System.Windows.Forms.Label();
            this.lbl_windSpeedday2 = new System.Windows.Forms.Label();
            this.lbl_tempday2 = new System.Windows.Forms.Label();
            this.lbl_windSpeedDay3 = new System.Windows.Forms.Label();
            this.lbl_tempDay3 = new System.Windows.Forms.Label();
            this.lbl_windSpeedday4 = new System.Windows.Forms.Label();
            this.lbl_tempDay4 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnShowNextDays = new System.Windows.Forms.Button();
            this.btnRandom = new System.Windows.Forms.Button();
            this.lbl_region = new System.Windows.Forms.Label();
            this.lbl_windDirday1 = new System.Windows.Forms.Label();
            this.lbl_pressureday1 = new System.Windows.Forms.Label();
            this.lbl_windDirecday2 = new System.Windows.Forms.Label();
            this.lbl_pressureDay2 = new System.Windows.Forms.Label();
            this.lbl_windDirecday3 = new System.Windows.Forms.Label();
            this.lbl_windDirectday4 = new System.Windows.Forms.Label();
            this.lbl_pressureDay3 = new System.Windows.Forms.Label();
            this.lbl_pressureDay4 = new System.Windows.Forms.Label();
            this.lbl_search = new System.Windows.Forms.Label();
            this.lblwarning = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbTowns
            // 
            this.cmbTowns.FormattingEnabled = true;
            this.cmbTowns.Location = new System.Drawing.Point(31, 4);
            this.cmbTowns.Name = "cmbTowns";
            this.cmbTowns.Size = new System.Drawing.Size(178, 21);
            this.cmbTowns.TabIndex = 0;
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(368, 5);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(176, 20);
            this.txt_search.TabIndex = 1;
            // 
            // lblTemp
            // 
            this.lblTemp.AutoSize = true;
            this.lblTemp.Location = new System.Drawing.Point(379, 122);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(0, 13);
            this.lblTemp.TabIndex = 2;
            // 
            // lblTown
            // 
            this.lblTown.AutoSize = true;
            this.lblTown.Location = new System.Drawing.Point(197, 59);
            this.lblTown.Name = "lblTown";
            this.lblTown.Size = new System.Drawing.Size(62, 13);
            this.lblTown.TabIndex = 3;
            this.lblTown.Text = "TownName";
            // 
            // lblCondName
            // 
            this.lblCondName.AutoSize = true;
            this.lblCondName.Location = new System.Drawing.Point(291, 183);
            this.lblCondName.Name = "lblCondName";
            this.lblCondName.Size = new System.Drawing.Size(57, 13);
            this.lblCondName.TabIndex = 4;
            this.lblCondName.Text = "Condition: ";
            // 
            // lblPressureName
            // 
            this.lblPressureName.AutoSize = true;
            this.lblPressureName.Location = new System.Drawing.Point(291, 239);
            this.lblPressureName.Name = "lblPressureName";
            this.lblPressureName.Size = new System.Drawing.Size(54, 13);
            this.lblPressureName.TabIndex = 5;
            this.lblPressureName.Text = "Pressure: ";
            // 
            // lblWindSpeed
            // 
            this.lblWindSpeed.AutoSize = true;
            this.lblWindSpeed.Location = new System.Drawing.Point(291, 303);
            this.lblWindSpeed.Name = "lblWindSpeed";
            this.lblWindSpeed.Size = new System.Drawing.Size(72, 13);
            this.lblWindSpeed.TabIndex = 6;
            this.lblWindSpeed.Text = "Wind Speed: ";
            // 
            // lbl_condition
            // 
            this.lbl_condition.AutoSize = true;
            this.lbl_condition.Location = new System.Drawing.Point(379, 183);
            this.lbl_condition.Name = "lbl_condition";
            this.lbl_condition.Size = new System.Drawing.Size(0, 13);
            this.lbl_condition.TabIndex = 7;
            // 
            // lbl_pressure
            // 
            this.lbl_pressure.AutoSize = true;
            this.lbl_pressure.Location = new System.Drawing.Point(379, 239);
            this.lbl_pressure.Name = "lbl_pressure";
            this.lbl_pressure.Size = new System.Drawing.Size(0, 13);
            this.lbl_pressure.TabIndex = 8;
            // 
            // lblWind_Speed
            // 
            this.lblWind_Speed.AutoSize = true;
            this.lblWind_Speed.Location = new System.Drawing.Point(379, 303);
            this.lblWind_Speed.Name = "lblWind_Speed";
            this.lblWind_Speed.Size = new System.Drawing.Size(0, 13);
            this.lblWind_Speed.TabIndex = 9;
            // 
            // lbl_windDirect
            // 
            this.lbl_windDirect.AutoSize = true;
            this.lbl_windDirect.Location = new System.Drawing.Point(379, 338);
            this.lbl_windDirect.Name = "lbl_windDirect";
            this.lbl_windDirect.Size = new System.Drawing.Size(0, 13);
            this.lbl_windDirect.TabIndex = 10;
            // 
            // lblWindDirecName
            // 
            this.lblWindDirecName.AutoSize = true;
            this.lblWindDirecName.Location = new System.Drawing.Point(291, 338);
            this.lblWindDirecName.Name = "lblWindDirecName";
            this.lblWindDirecName.Size = new System.Drawing.Size(83, 13);
            this.lblWindDirecName.TabIndex = 11;
            this.lblWindDirecName.Text = "Wind Direction: ";
            // 
            // lblTempName
            // 
            this.lblTempName.AutoSize = true;
            this.lblTempName.Location = new System.Drawing.Point(291, 122);
            this.lblTempName.Name = "lblTempName";
            this.lblTempName.Size = new System.Drawing.Size(70, 13);
            this.lblTempName.TabIndex = 12;
            this.lblTempName.Text = "Temperature:";
            // 
            // lbl_date1
            // 
            this.lbl_date1.AutoSize = true;
            this.lbl_date1.Location = new System.Drawing.Point(520, 70);
            this.lbl_date1.Name = "lbl_date1";
            this.lbl_date1.Size = new System.Drawing.Size(34, 13);
            this.lbl_date1.TabIndex = 13;
            this.lbl_date1.Text = "date1";
            // 
            // lbl_condday1
            // 
            this.lbl_condday1.AutoSize = true;
            this.lbl_condday1.Location = new System.Drawing.Point(686, 70);
            this.lbl_condday1.Name = "lbl_condday1";
            this.lbl_condday1.Size = new System.Drawing.Size(51, 13);
            this.lbl_condday1.TabIndex = 14;
            this.lbl_condday1.Text = "Condition";
            // 
            // lbl_condday2
            // 
            this.lbl_condday2.AutoSize = true;
            this.lbl_condday2.Location = new System.Drawing.Point(686, 192);
            this.lbl_condday2.Name = "lbl_condday2";
            this.lbl_condday2.Size = new System.Drawing.Size(51, 13);
            this.lbl_condday2.TabIndex = 15;
            this.lbl_condday2.Text = "Condition";
            // 
            // lbl_date2
            // 
            this.lbl_date2.AutoSize = true;
            this.lbl_date2.Location = new System.Drawing.Point(520, 192);
            this.lbl_date2.Name = "lbl_date2";
            this.lbl_date2.Size = new System.Drawing.Size(34, 13);
            this.lbl_date2.TabIndex = 16;
            this.lbl_date2.Text = "date2";
            // 
            // lbl_condday3
            // 
            this.lbl_condday3.AutoSize = true;
            this.lbl_condday3.Location = new System.Drawing.Point(686, 318);
            this.lbl_condday3.Name = "lbl_condday3";
            this.lbl_condday3.Size = new System.Drawing.Size(51, 13);
            this.lbl_condday3.TabIndex = 17;
            this.lbl_condday3.Text = "Condition";
            // 
            // lbl_date3
            // 
            this.lbl_date3.AutoSize = true;
            this.lbl_date3.Location = new System.Drawing.Point(520, 318);
            this.lbl_date3.Name = "lbl_date3";
            this.lbl_date3.Size = new System.Drawing.Size(34, 13);
            this.lbl_date3.TabIndex = 18;
            this.lbl_date3.Text = "date3";
            // 
            // lbl_condDay4
            // 
            this.lbl_condDay4.AutoSize = true;
            this.lbl_condDay4.Location = new System.Drawing.Point(677, 432);
            this.lbl_condDay4.Name = "lbl_condDay4";
            this.lbl_condDay4.Size = new System.Drawing.Size(51, 13);
            this.lbl_condDay4.TabIndex = 19;
            this.lbl_condDay4.Text = "Condition";
            // 
            // lbl_date4
            // 
            this.lbl_date4.AutoSize = true;
            this.lbl_date4.Location = new System.Drawing.Point(520, 432);
            this.lbl_date4.Name = "lbl_date4";
            this.lbl_date4.Size = new System.Drawing.Size(34, 13);
            this.lbl_date4.TabIndex = 20;
            this.lbl_date4.Text = "date4";
            // 
            // lbl_CountryName
            // 
            this.lbl_CountryName.AutoSize = true;
            this.lbl_CountryName.Location = new System.Drawing.Point(385, 59);
            this.lbl_CountryName.Name = "lbl_CountryName";
            this.lbl_CountryName.Size = new System.Drawing.Size(43, 13);
            this.lbl_CountryName.TabIndex = 21;
            this.lbl_CountryName.Text = "Country";
            // 
            // lbl_tempday1
            // 
            this.lbl_tempday1.AutoSize = true;
            this.lbl_tempday1.Location = new System.Drawing.Point(609, 70);
            this.lbl_tempday1.Name = "lbl_tempday1";
            this.lbl_tempday1.Size = new System.Drawing.Size(30, 13);
            this.lbl_tempday1.TabIndex = 22;
            this.lbl_tempday1.Text = "temp";
            // 
            // lbl_windSpeedday1
            // 
            this.lbl_windSpeedday1.AutoSize = true;
            this.lbl_windSpeedday1.Location = new System.Drawing.Point(595, 93);
            this.lbl_windSpeedday1.Name = "lbl_windSpeedday1";
            this.lbl_windSpeedday1.Size = new System.Drawing.Size(66, 13);
            this.lbl_windSpeedday1.TabIndex = 23;
            this.lbl_windSpeedday1.Text = "Wind Speed";
            // 
            // lbl_windSpeedday2
            // 
            this.lbl_windSpeedday2.AutoSize = true;
            this.lbl_windSpeedday2.Location = new System.Drawing.Point(595, 225);
            this.lbl_windSpeedday2.Name = "lbl_windSpeedday2";
            this.lbl_windSpeedday2.Size = new System.Drawing.Size(63, 13);
            this.lbl_windSpeedday2.TabIndex = 24;
            this.lbl_windSpeedday2.Text = "WindSpeed";
            // 
            // lbl_tempday2
            // 
            this.lbl_tempday2.AutoSize = true;
            this.lbl_tempday2.Location = new System.Drawing.Point(602, 192);
            this.lbl_tempday2.Name = "lbl_tempday2";
            this.lbl_tempday2.Size = new System.Drawing.Size(67, 13);
            this.lbl_tempday2.TabIndex = 25;
            this.lbl_tempday2.Text = "Temperature";
            // 
            // lbl_windSpeedDay3
            // 
            this.lbl_windSpeedDay3.AutoSize = true;
            this.lbl_windSpeedDay3.Location = new System.Drawing.Point(591, 351);
            this.lbl_windSpeedDay3.Name = "lbl_windSpeedDay3";
            this.lbl_windSpeedDay3.Size = new System.Drawing.Size(63, 13);
            this.lbl_windSpeedDay3.TabIndex = 26;
            this.lbl_windSpeedDay3.Text = "WindSpeed";
            // 
            // lbl_tempDay3
            // 
            this.lbl_tempDay3.AutoSize = true;
            this.lbl_tempDay3.Location = new System.Drawing.Point(591, 318);
            this.lbl_tempDay3.Name = "lbl_tempDay3";
            this.lbl_tempDay3.Size = new System.Drawing.Size(67, 13);
            this.lbl_tempDay3.TabIndex = 27;
            this.lbl_tempDay3.Text = "Temperature";
            // 
            // lbl_windSpeedday4
            // 
            this.lbl_windSpeedday4.AutoSize = true;
            this.lbl_windSpeedday4.Location = new System.Drawing.Point(589, 461);
            this.lbl_windSpeedday4.Name = "lbl_windSpeedday4";
            this.lbl_windSpeedday4.Size = new System.Drawing.Size(63, 13);
            this.lbl_windSpeedday4.TabIndex = 28;
            this.lbl_windSpeedday4.Text = "WindSpeed";
            // 
            // lbl_tempDay4
            // 
            this.lbl_tempDay4.AutoSize = true;
            this.lbl_tempDay4.Location = new System.Drawing.Point(591, 432);
            this.lbl_tempDay4.Name = "lbl_tempDay4";
            this.lbl_tempDay4.Size = new System.Drawing.Size(67, 13);
            this.lbl_tempDay4.TabIndex = 29;
            this.lbl_tempDay4.Text = "Temperature";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(568, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(233, 23);
            this.btnSave.TabIndex = 36;
            this.btnSave.Text = "Save Your Weather";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnShowNextDays
            // 
            this.btnShowNextDays.Location = new System.Drawing.Point(31, 432);
            this.btnShowNextDays.Name = "btnShowNextDays";
            this.btnShowNextDays.Size = new System.Drawing.Size(243, 23);
            this.btnShowNextDays.TabIndex = 37;
            this.btnShowNextDays.Text = "Show Next 4 days";
            this.btnShowNextDays.UseVisualStyleBackColor = true;
            this.btnShowNextDays.Click += new System.EventHandler(this.btnShowNextDays_Click);
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(31, 461);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(243, 23);
            this.btnRandom.TabIndex = 38;
            this.btnRandom.Text = "Random Weather (make a wish!)";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // lbl_region
            // 
            this.lbl_region.AutoSize = true;
            this.lbl_region.Location = new System.Drawing.Point(291, 59);
            this.lbl_region.Name = "lbl_region";
            this.lbl_region.Size = new System.Drawing.Size(41, 13);
            this.lbl_region.TabIndex = 39;
            this.lbl_region.Text = "Region";
            // 
            // lbl_windDirday1
            // 
            this.lbl_windDirday1.AutoSize = true;
            this.lbl_windDirday1.Location = new System.Drawing.Point(686, 93);
            this.lbl_windDirday1.Name = "lbl_windDirday1";
            this.lbl_windDirday1.Size = new System.Drawing.Size(77, 13);
            this.lbl_windDirday1.TabIndex = 40;
            this.lbl_windDirday1.Text = "Wind Direction";
            // 
            // lbl_pressureday1
            // 
            this.lbl_pressureday1.AutoSize = true;
            this.lbl_pressureday1.Location = new System.Drawing.Point(602, 122);
            this.lbl_pressureday1.Name = "lbl_pressureday1";
            this.lbl_pressureday1.Size = new System.Drawing.Size(48, 13);
            this.lbl_pressureday1.TabIndex = 41;
            this.lbl_pressureday1.Text = "Pressure";
            // 
            // lbl_windDirecday2
            // 
            this.lbl_windDirecday2.AutoSize = true;
            this.lbl_windDirecday2.Location = new System.Drawing.Point(686, 225);
            this.lbl_windDirecday2.Name = "lbl_windDirecday2";
            this.lbl_windDirecday2.Size = new System.Drawing.Size(77, 13);
            this.lbl_windDirecday2.TabIndex = 42;
            this.lbl_windDirecday2.Text = "Wind Direction";
            // 
            // lbl_pressureDay2
            // 
            this.lbl_pressureDay2.AutoSize = true;
            this.lbl_pressureDay2.Location = new System.Drawing.Point(602, 253);
            this.lbl_pressureDay2.Name = "lbl_pressureDay2";
            this.lbl_pressureDay2.Size = new System.Drawing.Size(48, 13);
            this.lbl_pressureDay2.TabIndex = 43;
            this.lbl_pressureDay2.Text = "Pressure";
            // 
            // lbl_windDirecday3
            // 
            this.lbl_windDirecday3.AutoSize = true;
            this.lbl_windDirecday3.Location = new System.Drawing.Point(686, 351);
            this.lbl_windDirecday3.Name = "lbl_windDirecday3";
            this.lbl_windDirecday3.Size = new System.Drawing.Size(77, 13);
            this.lbl_windDirecday3.TabIndex = 44;
            this.lbl_windDirecday3.Text = "Wind Direction";
            // 
            // lbl_windDirectday4
            // 
            this.lbl_windDirectday4.AutoSize = true;
            this.lbl_windDirectday4.Location = new System.Drawing.Point(686, 461);
            this.lbl_windDirectday4.Name = "lbl_windDirectday4";
            this.lbl_windDirectday4.Size = new System.Drawing.Size(77, 13);
            this.lbl_windDirectday4.TabIndex = 45;
            this.lbl_windDirectday4.Text = "Wind Direction";
            // 
            // lbl_pressureDay3
            // 
            this.lbl_pressureDay3.AutoSize = true;
            this.lbl_pressureDay3.Location = new System.Drawing.Point(591, 382);
            this.lbl_pressureDay3.Name = "lbl_pressureDay3";
            this.lbl_pressureDay3.Size = new System.Drawing.Size(48, 13);
            this.lbl_pressureDay3.TabIndex = 46;
            this.lbl_pressureDay3.Text = "Pressure";
            // 
            // lbl_pressureDay4
            // 
            this.lbl_pressureDay4.AutoSize = true;
            this.lbl_pressureDay4.Location = new System.Drawing.Point(591, 485);
            this.lbl_pressureDay4.Name = "lbl_pressureDay4";
            this.lbl_pressureDay4.Size = new System.Drawing.Size(48, 13);
            this.lbl_pressureDay4.TabIndex = 47;
            this.lbl_pressureDay4.Text = "Pressure";
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Location = new System.Drawing.Point(248, 8);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(112, 13);
            this.lbl_search.TabIndex = 48;
            this.lbl_search.Text = "Search the town here:";
            // 
            // lblwarning
            // 
            this.lblwarning.AutoSize = true;
            this.lblwarning.ForeColor = System.Drawing.Color.Red;
            this.lblwarning.Location = new System.Drawing.Point(365, 28);
            this.lblwarning.Name = "lblwarning";
            this.lblwarning.Size = new System.Drawing.Size(0, 13);
            this.lblwarning.TabIndex = 49;
            // 
            // WeatherControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblwarning);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.lbl_pressureDay4);
            this.Controls.Add(this.lbl_pressureDay3);
            this.Controls.Add(this.lbl_windDirectday4);
            this.Controls.Add(this.lbl_windDirecday3);
            this.Controls.Add(this.lbl_pressureDay2);
            this.Controls.Add(this.lbl_windDirecday2);
            this.Controls.Add(this.lbl_pressureday1);
            this.Controls.Add(this.lbl_windDirday1);
            this.Controls.Add(this.lbl_region);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.btnShowNextDays);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lbl_tempDay4);
            this.Controls.Add(this.lbl_windSpeedday4);
            this.Controls.Add(this.lbl_tempDay3);
            this.Controls.Add(this.lbl_windSpeedDay3);
            this.Controls.Add(this.lbl_tempday2);
            this.Controls.Add(this.lbl_windSpeedday2);
            this.Controls.Add(this.lbl_windSpeedday1);
            this.Controls.Add(this.lbl_tempday1);
            this.Controls.Add(this.lbl_CountryName);
            this.Controls.Add(this.lbl_date4);
            this.Controls.Add(this.lbl_condDay4);
            this.Controls.Add(this.lbl_date3);
            this.Controls.Add(this.lbl_condday3);
            this.Controls.Add(this.lbl_date2);
            this.Controls.Add(this.lbl_condday2);
            this.Controls.Add(this.lbl_condday1);
            this.Controls.Add(this.lbl_date1);
            this.Controls.Add(this.lblTempName);
            this.Controls.Add(this.lblWindDirecName);
            this.Controls.Add(this.lbl_windDirect);
            this.Controls.Add(this.lblWind_Speed);
            this.Controls.Add(this.lbl_pressure);
            this.Controls.Add(this.lbl_condition);
            this.Controls.Add(this.lblWindSpeed);
            this.Controls.Add(this.lblPressureName);
            this.Controls.Add(this.lblCondName);
            this.Controls.Add(this.lblTown);
            this.Controls.Add(this.lblTemp);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.cmbTowns);
            this.Name = "WeatherControl";
            this.Size = new System.Drawing.Size(866, 555);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTowns;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label lblTemp;
        private System.Windows.Forms.Label lblTown;
        private System.Windows.Forms.Label lblCondName;
        private System.Windows.Forms.Label lblPressureName;
        private System.Windows.Forms.Label lblWindSpeed;
        private System.Windows.Forms.Label lbl_condition;
        private System.Windows.Forms.Label lbl_pressure;
        private System.Windows.Forms.Label lblWind_Speed;
        private System.Windows.Forms.Label lbl_windDirect;
        private System.Windows.Forms.Label lblWindDirecName;
        private System.Windows.Forms.Label lblTempName;
        private System.Windows.Forms.Label lbl_date1;
        private System.Windows.Forms.Label lbl_condday1;
        private System.Windows.Forms.Label lbl_condday2;
        private System.Windows.Forms.Label lbl_date2;
        private System.Windows.Forms.Label lbl_condday3;
        private System.Windows.Forms.Label lbl_date3;
        private System.Windows.Forms.Label lbl_condDay4;
        private System.Windows.Forms.Label lbl_date4;
        private System.Windows.Forms.Label lbl_CountryName;
        private System.Windows.Forms.Label lbl_tempday1;
        private System.Windows.Forms.Label lbl_windSpeedday1;
        private System.Windows.Forms.Label lbl_windSpeedday2;
        private System.Windows.Forms.Label lbl_tempday2;
        private System.Windows.Forms.Label lbl_windSpeedDay3;
        private System.Windows.Forms.Label lbl_tempDay3;
        private System.Windows.Forms.Label lbl_windSpeedday4;
        private System.Windows.Forms.Label lbl_tempDay4;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnShowNextDays;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Label lbl_region;
        private System.Windows.Forms.Label lbl_windDirday1;
        private System.Windows.Forms.Label lbl_pressureday1;
        private System.Windows.Forms.Label lbl_windDirecday2;
        private System.Windows.Forms.Label lbl_pressureDay2;
        private System.Windows.Forms.Label lbl_windDirecday3;
        private System.Windows.Forms.Label lbl_windDirectday4;
        private System.Windows.Forms.Label lbl_pressureDay3;
        private System.Windows.Forms.Label lbl_pressureDay4;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Label lblwarning;
    }
}
