﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Xml;
using System.Data;
using System.Xml.Linq;
using Weather.Properties;
using System.IO;
using System.Reflection;

namespace Weather
{
    //class Controller is responsible for the main logic of the application
    //written by Elena Shuvaeva 11/04/2016
    class Controller
    {
       

        #region Properties

        public List<Town> Towns { get; private set; }
        public List<Country> Countries { get; private set; }
        public Dictionary<Town, Forecast> Forecasts { get; private set; }
        public  Forecast Forecast { get; }
        public List<SingleForecast> SingleForecasts { get; private set; }
        #endregion

        #region Constructor
        public Controller()
        {
            InitialiseModel();
       
        }

        #endregion


        //Initialise Countries and Towns
        private void InitialiseModel()
        {
            InitialiseCountries();
            InitialiseTowns();
           
        } 

        //Add countries to the list of countries
        private void InitialiseCountries()
        {
            this.Countries = new List<Country>();
            Countries.Add(new Country("New Zealand"));
           Countries.Add(new Country("Australia"));
          
        }

        //Add countries to the list of towns
        public List<Town> InitialiseTowns()
        {
            this.Towns = new List<Town>();

            Country newzealand = Countries.Where(c => c.Name == "New Zealand").FirstOrDefault();
            Towns.Add(new Town("Auckland", newzealand,"Auckland" ));
            Towns.Add(new Town("Wellington", newzealand, "Wellington"));
            Towns.Add(new Town( "Christchurch", newzealand, "Canterbury"));
            Towns.Add(new Town("Tauranga", newzealand, "Bay_of_Plenty"));
            Towns.Add(new Town( "Whangarei", newzealand, "Northland"));
            

            Country australia = Countries.Where(c => c.Name == "Australia").FirstOrDefault();
            Towns.Add(new Town("Melbourne", australia, "Victoria"));
            Towns.Add(new Town("Sydney", australia, "New_South_Wales"));
            Towns.Add(new Town("Brisbane", australia, "Queensland"));
            return Towns;

        }


        /// <summary>
        ///  Getting forecast for the specified town
        /// </summary>


        public Forecast GetWeatherByTown(Town town)
        {
            Forecast result = null;

            if (town == null)
            {
                return result;
            }

            bool internetAccess = true;

            XDocument xml;

            //getting internet connection and xml from the internet
            try
            {
                String url = @"http://www.yr.no/place/";

                url += SubstituteSpaces(town.Country.Name) + @"/";
                url += town.Region + @"/";
                url += town.TownName;

                url += @"/forecast.xml";
               
                xml = XDocument.Load(url);
                result = ProcessXML(xml, town);

            }
            catch(Exception)
            {
                internetAccess = false;
            }
            // if no internet access  local xml will be loaded
            if (!internetAccess)
            {
                var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
                var iconPath = Path.Combine(outPutDirectory, @"xmlFiles\\"+ town.TownName+ ".xml");
                string icon_path = new Uri(iconPath).LocalPath;
               
                FileStream docIn = new FileStream(icon_path, FileMode.Open);
                xml = XDocument.Load(docIn);
                result = ProcessXML(xml, town);
            }

            return result;
        }


        /// <summary>
        /// Processing xml file and getting forecast for the town
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="town"></param>
        /// <returns></returns>
        private Forecast ProcessXML(XDocument xml, Town town)
        {
            Forecast result = null;
            XElement forecastElement = xml.Root.Elements().Where(e => e.Name.LocalName.ToLower() == "forecast").FirstOrDefault();


            if (forecastElement == null)
            {
                return result;
            }

            XElement tabularElement = forecastElement.Elements().Where(e => e.Name.LocalName.ToLower() == "tabular").FirstOrDefault();
            if (tabularElement == null)
            {
                return result;
            }

            List<XElement> timeForecasts = tabularElement.Elements().Where(e => e.Name.LocalName.ToLower() == "time").ToList();

            if (timeForecasts == null || timeForecasts.Count == 0)
            {
                return result;
            }

            //get first available time 
            var firstTimeELement = timeForecasts.FirstOrDefault();
            var firstDateRaw = firstTimeELement.Attribute("from").Value;

            DateTime day; // = DateTime.Today.Date;

            if (!DateTime.TryParse(firstDateRaw, out day))
            {
                return result;
            }

            day = day.Date;

            int days = 6;
            string[] daysNext = new string[days];

          

            SingleForecasts = new List<SingleForecast>();
            for (int a = 0; a < daysNext.Count(); a++)
            {
                DateTime currentDay = day.AddDays(a);
                string currentDayStr = currentDay.ToString("yyyy-MM-dd");
                daysNext[a] = currentDayStr;

                XElement timeElement = timeForecasts.Where(e => e.Attribute("from").Value.Contains(currentDayStr)).FirstOrDefault();
                SingleForecast currentDayForecast = ProcessTimeElement(timeElement, currentDay);
                SingleForecasts.Add(currentDayForecast);
            }


            result = new Forecast(town, SingleForecasts);
            return result;
        }

        /// <summary>
        /// Getting single forecast - the forecast for the specified day 
        /// </summary>
        /// <param name="timeElement"></param>
        /// <param name="date"></param>
        /// <returns></returns>

        private SingleForecast ProcessTimeElement(XElement timeElement, DateTime date)
        {
            SingleForecast result = null;
            string windDirection = "";
            XElement windDirectionElement = timeElement.Elements().Where(e => e.Name.LocalName == "windDirection").FirstOrDefault();

            if (windDirectionElement == null)
            {
                return result;
            }

            XAttribute windDirectionAttribute = windDirectionElement.Attributes().Where(a => a.Name.LocalName == "name").FirstOrDefault();

            if (windDirectionAttribute == null)
            {
                return result;
            }

            windDirection = windDirectionAttribute.Value;

            string windSpeed = "";
            XElement windSpeedElement = timeElement.Elements().Where(e => e.Name.LocalName == "windSpeed").FirstOrDefault();

            if (windSpeedElement == null)
            {
                return result;
            }

            XAttribute windSpeedAttribute = windSpeedElement.Attributes().Where(e => e.Name.LocalName == "name").FirstOrDefault();
            windSpeed = windSpeedAttribute.Value;
            string temperature = "";

            XElement temperatureEl = timeElement.Elements().Where(e => e.Name.LocalName == "temperature").FirstOrDefault();
            if (temperatureEl == null)
            {
                return result;
            }
            XAttribute temeratureAttribute = temperatureEl.Attributes().Where(e => e.Name.LocalName == "value").FirstOrDefault();
            temperature = temeratureAttribute.Value;
            string condition = "";

            XElement conditionEl = timeElement.Elements().Where(e => e.Name.LocalName == "symbol").FirstOrDefault();
            if (conditionEl == null)
            {
                return result;
            }

            XAttribute conditionAttr = conditionEl.Attributes().Where(e => e.Name.LocalName == "name").FirstOrDefault();
            condition = conditionAttr.Value;
            string pressure = "";
            if (pressure == null)
            {
                return result;
            }
            XElement pressureEl = timeElement.Elements().Where(e => e.Name.LocalName == "pressure").FirstOrDefault();
            XAttribute pressureAttr = pressureEl.Attributes().Where(e => e.Name.LocalName == "value").FirstOrDefault();
            pressure = pressureAttr.Value;

            result = new SingleForecast(windDirection, temperature, windSpeed, condition, pressure, date);
            return result;

        }

        /// <summary>
        /// adjusting string path to xml in the internet 
        /// </summary>
        /// <param name="toSubsitute"></param>
        /// <returns></returns>
        private string SubstituteSpaces(string toSubsitute)
        {
            return toSubsitute.Replace(" ", "_");
        }

       /// <summary>
       /// Initialising dictionary where town-key, forecast-value
       /// </summary>
        public void LoadForecasts()
        {
            this.Forecasts = new Dictionary<Town, Forecast>();
            foreach (Town town in Towns)
            {
                Forecast f = GetWeatherByTown(town);
                this.Forecasts.Add(town,f);
            }
        }

        /// <summary>
        /// Searching the town=>returns List with towns that match the search
        /// </summary>
        /// <param name="searchTown"></param>
        /// <returns></returns>
        public List<Town> GetTowns(string searchTown)
        {
          List<Town> tws=  this.Towns.Where(t => t.TownName.ToUpper().Contains(searchTown.ToUpper())).ToList();
           if (tws.Count!=0)
            {
                return tws;
            }
           else //return default town Auckland if the search is incorrect
            {
                return this.Towns.Where(t => t.TownName == "Auckland").ToList();
            }
           
        }

   /// <summary>
   /// getting random town. We use it to load a random forecast 
   /// </summary>
   /// <returns></returns>
        public Town  GetRandomWeather()
        {
            Town randomTown = null;

            if (this.Towns!= null)
            {
                int townCount = this.Towns.Count;

                Random r = new Random();
                int index = r.Next(0, townCount - 1);

                randomTown = this.Towns[index];

            }


            return randomTown;

        }
   


    }
}
