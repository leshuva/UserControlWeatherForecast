﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Weather
{
    //class Town is responsible for getting values for the town
    //written by Elena Shuvaeva 11/04/2016
    public class Town
    {
        private string _townName;
        private Country _country;
        private string _region;
        public string TownName { get { return _townName; } }
        public Country Country { get { return _country; } }
      
        public string Region { get { return _region; } }
        /// <summary>
        ///  constructor
        /// </summary>


        public Town(string name, Country country, string region)
        {
            _townName = name;
          
            _country = country;
            _region = region;
        }

        /// <summary>
        /// override to show string name in the combobox
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return _townName+ ", " + _country.Name;
        }

    }

}
