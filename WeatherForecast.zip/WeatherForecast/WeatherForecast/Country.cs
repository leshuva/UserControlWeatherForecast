﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weather
{
    //class Country is responsible for getting values for the country
    //written by Elena Shuvaeva 11/04/2016
    public class Country
    {
        private string _countryName;

        public string Name { get { return _countryName; } }

        public Country(string name)
        {
            _countryName = name;
        }
      
    }
}
