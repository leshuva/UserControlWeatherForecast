﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weather
{
    //class SingleForecast is responsible for getting values for the forecast for a single day
    //written by Elena Shuvaeva 11/04/2016

    public class SingleForecast
    {

        public string WindDirection { get; private set; }
        public string Temperature { get; private set; }
        public string WindSpeed { get; private set; }
        public string Condition { get; private set; }
        public string Pressure { get; private set; }
        public DateTime Date { get; private set; }

        public SingleForecast(string windDirection, string temperature, string windSpeed, string condition, string pressure, DateTime date)
        {
            WindDirection = windDirection;
            Temperature = temperature;
            WindSpeed = windSpeed;
            Condition = condition;
            Pressure = pressure;
            Date = date;

        }

    }
}
