﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Web;
using System.Text.RegularExpressions;

namespace Weather
{
    public partial class WeatherControl : UserControl
    {
        private Controller _cont;

        private Forecast _forecast;

        /// <summary>
        /// Constructor
        /// </summary>
        public WeatherControl()
        {
            InitializeComponent();
            _cont = new Controller();

            this.LoadCombobox();

            txt_search.TextChanged += txt_search_TextChanged;
            cmbTowns.SelectedValueChanged += CmbTown_SelectedValueChanged;

            this.GetWeatherByTown();
            LoadLabels(_forecast);

        }

        /// <summary>
        ///Bind towns to combobox
        /// </summary>
        private void LoadCombobox()
        {
            List<Town> towns = new List<Town>();
            towns = _cont.InitialiseTowns();
            cmbTowns.DataSource = towns;
        }
        /// <summary>
        /// Loading weather in the town that user chose in the combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void CmbTown_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbTowns.SelectedItem != null)
            {
                this.GetWeatherByTown();
                LoadLabels(_forecast);

            }
        }
        /// <summary>
        /// Getting forecast object (forecast in the chosen town)
        /// </summary>
        /// <returns></returns>
        private Forecast GetWeatherByTown()
        {
            
            Town town = cmbTowns.SelectedItem as Town;

            if (town == null)
            {
                return null;
            }
            try
            {
                _forecast = _cont.GetWeatherByTown(town);
            }
            catch (Exception ex)
            {
               //MessageBox.Show("The current weather cannot be loaded now due to internet connection problem. Please try again after a while. Thanks");
            }
            return _forecast;
        }

        /// <summary>
        /// Loading weather parameters for today. 
        /// </summary>
        private void LoadLabels(Forecast forecast)
        {
           
            if (forecast != null)
            {

                lblTemp.Text = forecast.Temperature + "C";
                lblTown.Text = forecast.Town.TownName;
                lbl_region.Text = forecast.Town.Region;


                lbl_condition.Text = forecast.Condition;
                lbl_pressure.Text = forecast.Pressure + " hPa";
                lblWind_Speed.Text = forecast.Windspeed;

                lbl_date1.Visible = false;
                lbl_date2.Visible = false;
                lbl_date3.Visible = false;
                lbl_date4.Visible = false;
                lbl_CountryName.Text = forecast.Town.Country.Name;
                lbl_condday1.Visible = false;
                lbl_condday2.Visible = false;
                lbl_condday3.Visible = false;
                lbl_condDay4.Visible = false;

                lbl_tempday1.Visible = false;
                lbl_tempday2.Visible = false;
                lbl_tempDay3.Visible = false;
                lbl_tempDay4.Visible = false;
                lbl_windSpeedday1.Visible = false;
                lbl_windSpeedday2.Visible = false;
                lbl_windSpeedDay3.Visible = false;
                lbl_windSpeedday4.Visible = false;
                lbl_windDirday1.Visible = false;
                lbl_windDirecday2.Visible = false;
                lbl_windDirecday3.Visible = false;
                lbl_windDirectday4.Visible = false;
                lbl_pressureday1.Visible = false;
                lbl_pressureDay2.Visible = false;
                lbl_pressureDay3.Visible = false;
                lbl_pressureDay4.Visible = false;

               
                lbl_windDirect.Text = forecast.WindDirection;

            }
            else
            {
                MessageBox.Show("The current weather cannot be loaded now due to internet connection problem. Please try again after a while. Thanks");

            }

        }

        /// <summary>
        /// Search the town name.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            //validation for search
            Regex regex = new Regex("^[a-zA-Z]+$");

            string townsearched= txt_search.Text;
       
            if (!(townsearched.Length == 0)&&(!regex.IsMatch(townsearched)))
            {
                lblwarning.Visible = true;
                lblwarning.ForeColor = Color.Red;
                lblwarning.Text="Input is incorrect, please input A-z characters";
                
                return;
            }
            else
            {
                lblwarning.Visible = false;
            }
           
    
            List<Town> town = _cont.GetTowns(txt_search.Text);

            cmbTowns.DataSource = town;
        }

        /// <summary>
        /// Button -show the weather for the next 4 days
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowNextDays_Click(object sender, EventArgs e)

        {
            Forecast forecast = null;
            try
            {
                 forecast = this.GetWeatherByTown();
            }
            catch (Exception)
            {
               
            }
            if (forecast != null)
            {
     
                LoadLabelsNextDays(forecast);
            }
            else
            {
                MessageBox.Show("the weather cannot be loaded due to the internet connection problem. ");
            }
        }

        /// <summary>
        /// Load labels for next days weather, Getting Single Forecasts from Forecast
        /// </summary>
        /// <param name="forecast"></param>
        private void LoadLabelsNextDays (Forecast forecast)
        {
            DateTime day = DateTime.Today.Date;
            lbl_date1.Visible = true;
            lbl_date2.Visible = true;
            lbl_date3.Visible = true;
            lbl_date4.Visible = true;
            lbl_condday1.Visible = true;
            lbl_condday2.Visible = true;
            lbl_condday3.Visible = true;
            lbl_condDay4.Visible = true;
            lbl_pressureday1.Visible = true;
            lbl_pressureDay2.Visible = true;
            lbl_pressureDay3.Visible = true;
            lbl_pressureDay4.Visible = true;
            lbl_tempday1.Visible = true;
            lbl_tempday2.Visible = true;
            lbl_tempDay3.Visible = true;
            lbl_tempDay4.Visible = true;
            lbl_windSpeedday2.Visible = true;
            lbl_windSpeedDay3.Visible = true;
            lbl_windSpeedday4.Visible = true;
            lbl_windDirday1.Visible = true;
            lbl_windDirecday2.Visible = true;
            lbl_windDirecday3.Visible = true;
            lbl_windDirectday4.Visible = true;
            lbl_date1.Text = day.AddDays(1).ToShortDateString();
            lbl_date2.Text = day.AddDays(2).ToShortDateString();
            lbl_date3.Text = day.AddDays(3).ToShortDateString();
            lbl_date4.Text = day.AddDays(4).ToShortDateString();
            lbl_CountryName.Text = forecast.Town.Country.Name;
            lbl_condday1.Text = forecast.SingleForecasts[1].Condition;
            lbl_condday2.Text = forecast.SingleForecasts[2].Condition;
            lbl_condday3.Text = forecast.SingleForecasts[3].Condition;
            lbl_condDay4.Text = forecast.SingleForecasts[4].Condition;
            lbl_pressureday1.Text = forecast.SingleForecasts[1].Pressure + " hPa";
            lbl_pressureDay2.Text = forecast.SingleForecasts[2].Pressure + " hPa";
            lbl_pressureDay3.Text = forecast.SingleForecasts[3].Pressure + " hPa";
            lbl_pressureDay4.Text = forecast.SingleForecasts[4].Pressure + " hPa";
            lbl_tempday1.Text = forecast.SingleForecasts[1].Temperature + "C";
            lbl_tempday2.Text = forecast.SingleForecasts[2].Temperature + "C";
            lbl_tempDay3.Text = forecast.SingleForecasts[3].Temperature + "C";
            lbl_tempDay4.Text = forecast.SingleForecasts[4].Temperature + "C";
            lbl_windDirday1.Text = forecast.SingleForecasts[1].WindDirection;
            lbl_windDirecday2.Text = forecast.SingleForecasts[2].WindDirection;
            lbl_windDirecday3.Text = forecast.SingleForecasts[3].WindDirection;
            lbl_windDirectday4.Text = forecast.SingleForecasts[4].WindDirection;
            lbl_windSpeedday1.Text = forecast.SingleForecasts[1].WindSpeed;
            lbl_windSpeedday2.Text = forecast.SingleForecasts[2].WindSpeed;
            lbl_windSpeedDay3.Text = forecast.SingleForecasts[3].WindSpeed;
            lbl_windSpeedday4.Text = forecast.SingleForecasts[4].WindSpeed;

        }

        /// <summary>
        /// Random weather. Random town is to be chosen and the weather there is to be shown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnRandom_Click(object sender, EventArgs e)

        {
            if (!(txt_search.Text.Length == 0))
            {
                lblwarning.Visible = true;
                lblwarning.Text = "Delete any symbols from the searchbox";
                return;

            }
            Town town = _cont.GetRandomWeather();
            cmbTowns.SelectedItem = town;
            this.GetWeatherByTown();
            this.LoadLabels(_forecast);
        }

        /// <summary>
        /// Save weather to txt file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        private void btnSave_Click(object sender, EventArgs e)
        {

            int arraysize = 5;
            string[] content = new string[50];
            string[] day = new string[arraysize];
            string[] town = new string[arraysize];
            string[] country = new string[arraysize];
            string[] region = new string[arraysize];
            string[] temperature = new string[arraysize];
            string[] windspeed = new string[arraysize];
            string[] windDirection = new string[arraysize];
            string[] condition = new string[arraysize];
            string[] pressure = new string[arraysize];

            //

            for (int i = 0; i < arraysize; i++)
            {

                day[i] = _forecast.SingleForecasts[i].Date.ToString() + " ";
                town[i] = _forecast.Town.TownName + " ";
                country[i] = _forecast.Town.Country.Name + " ";
                region[i] = _forecast.Town.Region + " ";
                temperature[i] = _forecast.SingleForecasts[i].Temperature + " ";
                windspeed[i] = _forecast.SingleForecasts[i].WindSpeed + " ";
                windDirection[i] = _forecast.SingleForecasts[i].WindDirection + " ";
                condition[i] = _forecast.SingleForecasts[i].Condition + " ";
                pressure[i] = _forecast.SingleForecasts[i].Pressure + " ";
                content[i] = "Date: " + day[i] + "\r\n" + "Town: " + town[i] + "\r\n" + "Country: " + country[i] + "\r\n" + "Region:" + region[i] + "\r\n" + "Temperature:" + temperature[i] + "C" + "\r\n" + "Wind speed: " + windspeed[i] + "\r\n" + "Wind direction:" + windDirection[i] + "\r\n" + "Pressure: " + pressure[i] + "\r\n";
            }


            SaveFileDialog savefileDialog = new SaveFileDialog();
            savefileDialog.Filter = "(*.txt)|*.txt";
            savefileDialog.Title = "Save As txt";

            if (savefileDialog.ShowDialog() == DialogResult.OK)
            {
                string path = savefileDialog.FileName;

                File.WriteAllLines(path, content);

            }

        }

      
    }
}
